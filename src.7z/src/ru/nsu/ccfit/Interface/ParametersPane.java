package ru.nsu.ccfit.Interface;

import javax.swing.*;
import java.awt.*;

public class ParametersPane extends JPanel {

    public ParametersPane() {
        super();
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 2, true));
        setBounds(200, 100, 300, 200);
        setVisible(true);

    }
}
